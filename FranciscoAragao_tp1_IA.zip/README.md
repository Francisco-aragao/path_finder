# path_finder

To run ``` python main.py <map file> <algorithm> <initial x> <initial y> <goal x> <goal y> ```

To run measuring time and number os expanded nodes ``` python main.py <map file> <algorithm> <initial x> <initial y> <goal x> <goal y> ```

The algorithms are:
- BFS
- IDS
- AStar
- Greedy
- UCS

There is no need to install any dependencies. There is only used the standard library of python.